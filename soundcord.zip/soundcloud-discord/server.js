const DiscordRPC = require('discord-rpc');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const clientId = '1510589031526830170';
let client;

async function initDiscord() {
  client = new DiscordRPC.Client({ transport: 'ipc' });
  
  client.on('ready', () => {
    console.log('✅ Discord RPC подключен');
  });

  try {
    await client.login({ clientId });
  } catch (err) {
    console.error('❌ Не удалось подключиться к Discord:', err);
  }
}

app.post('/update-presence', async (req, res) => {
  const { trackName, artistName, currentTime, duration, timeString } = req.body;

  if (!client) {
    return res.status(500).json({ error: 'Discord не инициализирован' });
  }

  try {
    // Рассчитываем время окончания трека
    const endTimestamp = Math.floor(Date.now() / 1000) + (duration - currentTime);

    await client.setActivity({
      details: `🎵 ${trackName}`,
      state: `by ${artistName} • ${timeString}`,
      largeImageKey: 'soundcloud',
      largeImageText: 'SoundCloud',
      endTimestamp: endTimestamp,
      instance: false,
    });

    res.json({ success: true, message: 'Presence обновлена' });
  } catch (err) {
    console.error('Ошибка при обновлении Presence:', err);
    res.status(500).json({ error: err.message });
  }
});

app.listen(3000, () => {
  console.log('🚀 Сервер запущен на http://localhost:3000');
});

initDiscord();
