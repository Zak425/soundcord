let lastDetectedTrack = '';

function getTrackInfo() {
  // Ищем текущий проигрываемый трек
  const trackName = document.querySelector('[itemprop="name"]')?.textContent || 
                    document.querySelector('a[href*="/tracks/"]')?.title || 
                    document.querySelector('.soundTitle__title')?.textContent || 
                    'Unknown Track';
  
  const artistName = document.querySelector('[itemprop="byArtist"]')?.textContent || 
                     document.querySelector('.soundTitle__username')?.textContent || 
                     'Unknown Artist';

  // Получаем текущее время воспроизведения
  const audioElement = document.querySelector('audio');
  const currentTime = audioElement ? Math.floor(audioElement.currentTime) : 0;
  const duration = audioElement ? Math.floor(audioElement.duration) : 0;

  // Конвертируем в минуты и секунды
  const currentMin = Math.floor(currentTime / 60);
  const currentSec = currentTime % 60;
  const durationMin = Math.floor(duration / 60);
  const durationSec = duration % 60;

  const timeString = `${currentMin}:${String(currentSec).padStart(2, '0')} / ${durationMin}:${String(durationSec).padStart(2, '0')}`;

  const currentTrack = `${trackName} - ${artistName}`;

  // Если трек изменился, отправляем в background
  if (currentTrack !== lastDetectedTrack && trackName.trim() !== '') {
    lastDetectedTrack = currentTrack;
    
    chrome.runtime.sendMessage({
      action: 'updateTrack',
      trackName: trackName.trim(),
      artistName: artistName.trim(),
      currentTime: currentTime,
      duration: duration,
      timeString: timeString
    });
  }
}

// Проверяем трек каждые 500мс
setInterval(getTrackInfo, 500);
getTrackInfo();
