let lastTrack = '';

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'updateTrack') {
    const { trackName, artistName, currentTime, duration, timeString } = request;
    
    if (lastTrack === `${trackName} - ${artistName}`) {
      return;
    }

    lastTrack = `${trackName} - ${artistName}`;

    // Отправляем на сервер с информацией о времени
    fetch('http://localhost:3000/update-presence', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        trackName, 
        artistName,
        currentTime,
        duration,
        timeString
      })
    })
      .then(res => res.json())
      .then(data => {
        console.log('✅ Discord обновлена:', trackName, '-', artistName, timeString);
      })
      .catch(err => {
        console.error('❌ Ошибка отправки:', err);
      });
  }
});
